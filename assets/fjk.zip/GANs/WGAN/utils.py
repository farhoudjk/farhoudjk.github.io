import torch
import numpy as np
import matplotlib.pyplot as plt
import os

def calculate_gradient_penalty(discriminator, real_samples, fake_samples, device='cuda'):
    """Calculate gradient penalty for WGAN-GP"""
    # Random weight for interpolation
    alpha = torch.rand(real_samples.size(0), 1).to(device)
    
    # Expand alpha to match the sample dimensions
    alpha = alpha.expand(real_samples.size(0), real_samples.size(1))
    
    # Interpolated samples
    interpolated = (alpha * real_samples + (1 - alpha) * fake_samples).requires_grad_(True)
    
    # Calculate discriminator output for interpolated samples
    d_interpolated = discriminator(interpolated)
    
    # Calculate gradients
    gradients = torch.autograd.grad(
        outputs=d_interpolated,
        inputs=interpolated,
        grad_outputs=torch.ones_like(d_interpolated).to(device),
        create_graph=True,
        retain_graph=True,
        only_inputs=True,
    )[0]
    
    # Calculate gradient penalty
    gradients = gradients.view(gradients.size(0), -1)
    gradient_norm = gradients.norm(2, dim=1)
    gradient_penalty = ((gradient_norm - 1) ** 2).mean()
    
    return gradient_penalty

def visualize_samples(generated_samples, real_samples, iteration, save_dir="./gan_results"):
    """Visualize and save generated vs real samples"""
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    
    # Get the number of features
    num_features = min(generated_samples.shape[1], 10)  # Limit to 10 features max
    
    # Create grid of subplots for each feature
    fig, axes = plt.subplots(num_features, 1, figsize=(10, 3*num_features))
    
    # Plot histograms for each feature
    for i in range(num_features):
        ax = axes[i] if num_features > 1 else axes
        ax.hist(real_samples[:, i], alpha=0.5, bins=30, label='Real Data', density=True)
        ax.hist(generated_samples[:, i], alpha=0.5, bins=30, label='Generated Data', density=True)
        ax.set_title(f'Feature {i+1}')
        ax.legend()
    
    plt.tight_layout()
    plt.savefig(f"{save_dir}/comparison_iter_{iteration}.png")
    plt.close()
