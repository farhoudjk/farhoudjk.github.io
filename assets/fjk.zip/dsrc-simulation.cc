#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/applications-module.h"
#include "ns3/mobility-module.h"
#include "ns3/wifi-module.h"
#include "ns3/internet-module.h"
#include "ns3/netanim-module.h"
#include "ns3/olsr-helper.h"  // Include OLSR routing

#include <cstdio>    // popen, fgets
#include <cstdlib>   // atoi
#include <sstream>   // ostringstream
#include <iostream>  // cout
#include <fstream>   // file operations

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("DsrcHighwaySimple");

// Function to check if Python scripts exist and directories are ready
bool CheckGanEnvironment() {
    // Check for Python scripts
    std::string scriptPath1 = "/home/yorku/Downloads/ns-allinone-3.43/ns-3.43/GANs/WGAN/run_generator.py";
    std::string scriptPath2 = "/home/yorku/Downloads/ns-allinone-3.43/ns-3.43/GANs/WGAN/run_discriminator.py";
    
    std::ifstream file1(scriptPath1.c_str());
    std::ifstream file2(scriptPath2.c_str());
    
    bool scriptsExist = file1.good() && file2.good();
    file1.close();
    file2.close();
    
    if (!scriptsExist) {
        NS_LOG_ERROR("GAN Python scripts not found at expected paths!");
        return false;
    }
    
    // Create necessary directories
    std::string baseDir = "/home/yorku/Downloads/ns-allinone-3.43/ns-3.43/GANs/WGAN/";
    std::string dirs[7]; // Needs 7 elements: 0, 1, and 2-6

    dirs[0] = baseDir + "results";
    dirs[1] = baseDir + "results/generator";
    
    for (int i = 1; i <= 5; i++) {
        std::ostringstream discDir;
        discDir << baseDir << "results/discriminator_" << i;
        dirs[i + 1] = discDir.str();
    }
    
    for (const std::string& dir : dirs) {
        std::string mkdirCmd = "mkdir -p " + dir;
        int status = system(mkdirCmd.c_str());
        if (status != 0) {
            NS_LOG_ERROR("Failed to create directory: " << dir);
            return false;
        }
    }
    
    return true;
}

// Custom Receive Callback with improved error handling and logging
void CustomServerReceiveCallback(Ptr<Socket> socket) {
    if (!socket) {
        NS_LOG_ERROR("Invalid socket pointer");
        return;
    }
    NS_LOG_INFO("CustomServerReceiveCallback triggered on node " << socket->GetNode()->GetId());
    printf("**************************\n");

    Ptr<Packet> packet;
    Address from;
    while ((packet = socket->RecvFrom(from))) {
        uint32_t nodeId = socket->GetNode()->GetId();
        InetSocketAddress inetFrom = InetSocketAddress::ConvertFrom(from);
        Ipv4Address senderAddr = inetFrom.GetIpv4();

        // Convert Ipv4Address to string using ostringstream
        std::ostringstream addrStream;
        senderAddr.Print(addrStream);
        std::string senderAddrStr = addrStream.str();

        NS_LOG_INFO("Node " << nodeId << " received packet from " << senderAddr << " of size " << packet->GetSize());
        printf("Received packet on node %u from %s\n", nodeId, senderAddrStr.c_str());

        // Only process packets for GAN nodes (0-5)
        if (nodeId > 5) {
            NS_LOG_UNCOND("Node " << nodeId << " is not configured for GAN training");
            continue;
        }

        // Create a command with full path
        std::ostringstream cmd;

        // Node 0 is the server (generator)
        // Nodes 1-5 are discriminators
        if (nodeId == 0) {
            printf("**************************\n");
            cmd << "python3 /home/yorku/Downloads/ns-allinone-3.43/ns-3.43/GANs/WGAN/run_generator.py " 
                << nodeId << " " << senderAddr.Get() << " > /home/yorku/Downloads/ns-allinone-3.43/ns-3.43/GANs/WGAN/results/generator/log_" 
                << time(NULL) << ".txt 2>&1";
        } else if (nodeId >= 1 && nodeId <= 5) {
            cmd << "python3 /home/yorku/Downloads/ns-allinone-3.43/ns-3.43/GANs/WGAN/run_discriminator.py " 
                << nodeId << " " << senderAddr.Get() << " > /home/yorku/Downloads/ns-allinone-3.43/ns-3.43/GANs/WGAN/results/discriminator_" 
                << nodeId << "/log_" << time(NULL) << ".txt 2>&1";
        } else {
            NS_LOG_UNCOND("Node " << nodeId << " is not configured for GAN training");
            continue;
        }

        NS_LOG_UNCOND("Executing: " << cmd.str());

        // Run command in background to avoid blocking simulation
        std::string bgCmd = cmd.str() + " &";

        // Check if the Python script exists before running
        std::string scriptPath = (nodeId == 0) ? 
            "/home/yorku/Downloads/ns-allinone-3.43/ns-3.43/GANs/WGAN/run_generator.py" : 
            "/home/yorku/Downloads/ns-allinone-3.43/ns-3.43/GANs/WGAN/run_discriminator.py";

        std::ifstream scriptFile(scriptPath.c_str());
        if (!scriptFile.good()) {
            NS_LOG_ERROR("Python script not found or not accessible: " << scriptPath);
            continue;
        }
        scriptFile.close();

        try {
            NS_LOG_UNCOND("About to execute system command");
            int status = system(bgCmd.c_str());
            NS_LOG_UNCOND("Command executed with status: " << status);

            if (status != 0) {
                NS_LOG_ERROR("Failed to start GAN script with status: " << status);
            } else {
                NS_LOG_UNCOND("GAN script started in background");
            }
        } catch (const std::exception& e) {
            NS_LOG_ERROR("Exception during command execution: " << e.what());
        }
    }
}

int main(int argc, char *argv[])
{
    uint32_t nVehicles = 50;
    double simTime = 120.0; // Even longer simulation time for GAN training
    bool verbose = true;

    CommandLine cmd(__FILE__);
    cmd.AddValue("nVehicles", "Number of vehicles", nVehicles);
    cmd.AddValue("simTime", "Simulation time in seconds", simTime);
    cmd.AddValue("verbose", "Enable verbose logging", verbose);
    cmd.Parse(argc, argv);

    // Check GAN environment at the beginning
    if (!CheckGanEnvironment()) {
        NS_LOG_ERROR("GAN environment setup issues detected. Please check the paths and permissions.");
        return 1;
    }

    // Enable logging
    if (verbose)
    {
        LogComponentEnable("DsrcHighwaySimple", LOG_LEVEL_INFO);
        LogComponentEnable("UdpEchoClientApplication", LOG_LEVEL_INFO);
        LogComponentEnable("Socket", LOG_LEVEL_INFO);
    }

    // Create vehicle nodes
    NS_LOG_INFO("Creating " << nVehicles << " vehicles");
    NodeContainer vehicles;
    vehicles.Create(nVehicles);

    // WiFi 802.11p setup
    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211p);

    YansWifiChannelHelper wifiChannel;
    wifiChannel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    wifiChannel.AddPropagationLoss("ns3::LogDistancePropagationLossModel", "Exponent", DoubleValue(3.0));

    YansWifiPhyHelper wifiPhy;
    wifiPhy.SetChannel(wifiChannel.Create());
    wifiPhy.Set("TxPowerStart", DoubleValue(23));
    wifiPhy.Set("TxPowerEnd", DoubleValue(23));

    wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                               "DataMode", StringValue("OfdmRate6MbpsBW10MHz"),
                               "ControlMode", StringValue("OfdmRate6MbpsBW10MHz"));

    WifiMacHelper wifiMac;
    wifiMac.SetType("ns3::AdhocWifiMac");

    NetDeviceContainer devices = wifi.Install(wifiPhy, wifiMac, vehicles);

    // Strategic positioning of GAN nodes
    Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator>();
    
    // Position generator (node 0) at center
    positionAlloc->Add(Vector(250.0, 250.0, 0.0));
    
    // Position discriminators in a circle around the generator
    double radius = 100.0;
    for (uint32_t i = 1; i <= 5; i++) {
        double angle = 2.0 * M_PI * (i - 1) / 5.0;
        double x = 250.0 + radius * cos(angle);
        double y = 250.0 + radius * sin(angle);
        positionAlloc->Add(Vector(x, y, 0.0));
    }
    
    // Random positions for other nodes
    for (uint32_t i = 6; i < nVehicles; i++) {
        double x = 500.0 * ((double) rand() / RAND_MAX);
        double y = 500.0 * ((double) rand() / RAND_MAX);
        positionAlloc->Add(Vector(x, y, 0.0));
    }

    // Different mobility models for different node types
    MobilityHelper mobility;
    mobility.SetPositionAllocator(positionAlloc);
    
    // Generator stays fixed
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(vehicles.Get(0));
    
    // Discriminators move slowly
    mobility.SetMobilityModel("ns3::RandomWalk2dMobilityModel",
                             "Bounds", RectangleValue(Rectangle(150, 350, 150, 350)),
                             "Speed", StringValue("ns3::UniformRandomVariable[Min=2|Max=5]"));
    
    for (uint32_t i = 1; i <= 5; i++) {
        mobility.Install(vehicles.Get(i));
    }
    
    // Other vehicles use normal mobility
    mobility.SetMobilityModel("ns3::RandomWalk2dMobilityModel",
                             "Bounds", RectangleValue(Rectangle(0, 500, 0, 500)),
                             "Speed", StringValue("ns3::UniformRandomVariable[Min=10|Max=100]"));
    
    for (uint32_t i = 6; i < nVehicles; i++) {
        mobility.Install(vehicles.Get(i));
    }

    // Internet stack setup with OLSR routing
    InternetStackHelper internet;
    OlsrHelper olsr;  // Add OLSR routing to ensure packet delivery
    internet.SetRoutingHelper(olsr);
    internet.Install(vehicles);

    // IP addressing
    Ipv4AddressHelper ipv4h;
    ipv4h.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = ipv4h.Assign(devices);
    
    // Configure nodes for IP forwarding
    for (uint32_t i = 0; i < nVehicles; i++) {
        Ptr<Ipv4> ipv4Interface = vehicles.Get(i)->GetObject<Ipv4>();
        ipv4Interface->SetAttribute("IpForward", BooleanValue(true));
    }

    // Create custom sockets for GAN nodes (generator and discriminators)
    uint16_t basePort = 9;
    for (uint32_t i = 0; i <= 5; i++) {
        TypeId tid = TypeId::LookupByName("ns3::UdpSocketFactory");
        Ptr<Socket> recvSocket = Socket::CreateSocket(vehicles.Get(i), tid);
        InetSocketAddress local = InetSocketAddress(Ipv4Address::GetAny(), basePort); // Bind to any address on port 9
        if (recvSocket->Bind(local) == -1) {
            NS_LOG_ERROR("Failed to bind socket on node " << i);
            return -1;
        }
        recvSocket->SetRecvCallback(MakeCallback(&CustomServerReceiveCallback));
        NS_LOG_INFO("Socket bound on node " << i << " to port " << basePort);
    }

    // 1. Discriminators send to generator
    ApplicationContainer discToGenApps;
    for (uint32_t i = 1; i <= 5; i++) {
        UdpEchoClientHelper client(interfaces.GetAddress(0), basePort);
        client.SetAttribute("MaxPackets", UintegerValue(20));
        client.SetAttribute("Interval", TimeValue(Seconds(15.0)));
        client.SetAttribute("PacketSize", UintegerValue(1024));
        
        ApplicationContainer app = client.Install(vehicles.Get(i));
        app.Start(Seconds(5.0 + i)); // Staggered start
        app.Stop(Seconds(simTime - 5.0));
        discToGenApps.Add(app);
        
        NS_LOG_INFO("Created client on discriminator " << i << " to send to generator at " << interfaces.GetAddress(0));
    }
    
    // 2. Generator sends to all discriminators
    ApplicationContainer genToDiscApps;
    for (uint32_t i = 1; i <= 5; i++) {
        UdpEchoClientHelper client(interfaces.GetAddress(i), basePort);
        client.SetAttribute("MaxPackets", UintegerValue(20));
        client.SetAttribute("Interval", TimeValue(Seconds(15.0))); 
        client.SetAttribute("PacketSize", UintegerValue(1024));
        
        ApplicationContainer app = client.Install(vehicles.Get(0));
        app.Start(Seconds(20.0)); // Start after discriminators have sent
        app.Stop(Seconds(simTime - 5.0));
        genToDiscApps.Add(app);
        
        NS_LOG_INFO("Created client on generator to send to discriminator " << i << " at " << interfaces.GetAddress(i));
    }
    
    // Add simple background traffic
    ApplicationContainer backgroundApps;
    for (uint32_t i = 6; i < std::min(nVehicles, (uint32_t)20); i++) {
        uint32_t dest = (i + 1) % nVehicles;
        if (dest < 6) dest = 6; // Don't send to GAN nodes
        
        UdpEchoClientHelper client(interfaces.GetAddress(dest), basePort + 1); // Use different port
        client.SetAttribute("MaxPackets", UintegerValue(5));
        client.SetAttribute("Interval", TimeValue(Seconds(10.0)));
        client.SetAttribute("PacketSize", UintegerValue(512));
        
        ApplicationContainer app = client.Install(vehicles.Get(i));
        app.Start(Seconds(10.0 + i * 0.2));
        app.Stop(Seconds(simTime - 10.0));
        backgroundApps.Add(app);
    }

    // Enable PCAP tracing
    wifiPhy.EnablePcap("dsrc-highway-gan", devices.Get(0)); // Generator
    for (uint32_t i = 1; i <= 5; i++) {
        std::ostringstream pcapName;
        pcapName << "dsrc-highway-gan-disc-" << i;
        wifiPhy.EnablePcap(pcapName.str(), devices.Get(i)); // Discriminators
    }

    // NetAnim setup with improved visuals
    AnimationInterface anim("dsrc-highway-gan-animation.xml");
    
    // Set node colors
    anim.UpdateNodeColor(vehicles.Get(0), 255, 0, 0);  // Red for generator
    anim.UpdateNodeSize(vehicles.Get(0), 15, 15);      // Larger size
    
    // Different colors for discriminators
    uint8_t discColors[][3] = {
        {0, 0, 255},    // Blue
        {128, 0, 128},  // Purple
        {0, 128, 128},  // Teal
        {128, 128, 0},  // Olive
        {0, 128, 0}     // Green
    };
    
    for (uint32_t i = 1; i <= 5; i++) {
        anim.UpdateNodeColor(vehicles.Get(i), discColors[i-1][0], discColors[i-1][1], discColors[i-1][2]);
        anim.UpdateNodeSize(vehicles.Get(i), 10, 10);
        
        std::ostringstream desc;
        desc << "Discriminator " << i;
        anim.UpdateNodeDescription(vehicles.Get(i), desc.str());
    }
    
    // Set regular nodes to gray
    for (uint32_t i = 6; i < nVehicles; i++) {
        anim.UpdateNodeColor(vehicles.Get(i), 180, 180, 180);  // Gray
    }
    
    // Add descriptive label for generator
    anim.UpdateNodeDescription(vehicles.Get(0), "Generator");
    
    // Run simulation
    NS_LOG_INFO("Starting simulation for " << simTime << " seconds");
    Simulator::Stop(Seconds(simTime + 1));
    Simulator::Run();
    Simulator::Destroy();

    NS_LOG_INFO("Simulation completed");
    return 0;
}
